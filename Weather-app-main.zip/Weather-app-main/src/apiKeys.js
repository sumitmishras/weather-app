// Visit https://api.openweathermap.org & then signup to get our API keys for free
module.exports = {
  key: "e59ba18c345a9aec400060cbc1b6a051",
  base: "https://api.openweathermap.org/data/2.5/",
};
